@extends('layouts.app')

@section('content')
    <div class="flex items-center justify-between mb-6">
        <h2 class="text-3xl font-bold text-gray-800">Add New Room</h2>
        <a href="{{ route('departments.index') }}" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded-lg shadow-md transition-colors duration-200 ease-in-out flex items-center">
            <svg class="w-5 h-5 inline-block mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
            Back to Departments
        </a>
    </div>

    <!-- Add Room Form -->
    <div class="bg-white rounded-xl shadow-lg p-6 mb-8">
        <h3 class="text-2xl font-semibold text-gray-800 mb-4">Room Details</h3>
        <form action="#" method="POST"> {{-- Action will be updated later for actual submission --}}
            @csrf {{-- Laravel CSRF token --}}
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                    <label for="floor_id" class="block text-gray-700 text-sm font-bold mb-2">Floor Name:</label>
                    <select id="floor_id" name="floor_id" class="shadow appearance-none border rounded-lg w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
                        <option value="">Select a Floor</option>
                        {{-- Static Floors for dropdown (matching the static data in Add Floor page) --}}
                        @php
                            $floors = [
                                ['id' => 'F001', 'name' => 'Ground Floor'],
                                ['id' => 'F002', 'name' => 'First Floor'],
                                ['id' => 'F003', 'name' => 'Second Floor'],
                                ['id' => 'F004', 'name' => 'Third Floor'],
                                ['id' => 'F005', 'name' => 'Basement'],
                            ];
                        @endphp
                        @foreach($floors as $floor)
                            <option value="{{ $floor['id'] }}">{{ $floor['name'] }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label for="room_name" class="block text-gray-700 text-sm font-bold mb-2">Room Name:</label>
                    <input type="text" id="room_name" name="room_name" class="shadow appearance-none border rounded-lg w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="e.g., Room 101, Ward A" required>
                </div>
                 <div>
                    <label for="per_day_rent" class="block text-gray-700 text-sm font-bold mb-2">Per Day Rent:</label>
                    <input type="number" id="per_day_rent" name="per_day_rent" class="shadow appearance-none border rounded-lg w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="e.g., 500" min="0" step="0.01">
                </div>
            </div>

            <div class="mb-6">
                <label class="inline-flex items-center">
                    <input type="checkbox" name="is_ward" id="is_ward" class="form-checkbox h-5 w-5 text-blue-600 rounded focus:ring-blue-500">
                    <span class="ml-2 text-gray-700 text-sm font-bold">This room is a Ward</span>
                </label>
            </div>

            <div id="ward_details" class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6 hidden">
                <div>
                    <label for="number_of_beds" class="block text-gray-700 text-sm font-bold mb-2">Number of Beds:</label>
                    <input type="number" id="number_of_beds" name="number_of_beds" class="shadow appearance-none border rounded-lg w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="e.g., 10" min="0">
                </div>
               
            </div>

            <div class="flex justify-end">
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-full shadow-lg transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                    Add Room
                </button>
            </div>
        </form>
    </div>

    <!-- Room List Table -->
    <div class="bg-white rounded-xl shadow-lg p-6">
        <h3 class="text-2xl font-semibold text-gray-800 mb-4">Existing Rooms</h3>
        <div class="overflow-x-auto">
            <table class="min-w-full bg-white rounded-lg overflow-hidden">
                <thead class="bg-gray-100 border-b border-gray-200">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sr. No.</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Room ID</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Room Name</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Floor Name</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Is Ward</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">No. of Beds</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Per Day Rent</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    {{-- Static Room Data --}}
                    @php
                        $rooms = [
                            ['id' => 'R001', 'name' => 'Room 101', 'floor' => 'First Floor', 'is_ward' => false, 'beds' => null, 'rent' => null],
                            ['id' => 'R002', 'name' => 'Ward A', 'floor' => 'Ground Floor', 'is_ward' => true, 'beds' => 15, 'rent' => 300],
                            ['id' => 'R003', 'name' => 'Room 205', 'floor' => 'Second Floor', 'is_ward' => false, 'beds' => null, 'rent' => null],
                            ['id' => 'R004', 'name' => 'ICU 1', 'floor' => 'First Floor', 'is_ward' => false, 'beds' => null, 'rent' => null],
                            ['id' => 'R005', 'name' => 'Ward B', 'floor' => 'Ground Floor', 'is_ward' => true, 'beds' => 20, 'rent' => 250],
                            ['id' => 'R006', 'name' => 'Room 302', 'floor' => 'Third Floor', 'is_ward' => false, 'beds' => null, 'rent' => null],
                            ['id' => 'R007', 'name' => 'Emergency Room 1', 'floor' => 'Ground Floor', 'is_ward' => false, 'beds' => null, 'rent' => null],
                            ['id' => 'R008', 'name' => 'Ward C', 'floor' => 'Second Floor', 'is_ward' => true, 'beds' => 10, 'rent' => 400],
                            ['id' => 'R009', 'name' => 'Operation Theater 1', 'floor' => 'First Floor', 'is_ward' => false, 'beds' => null, 'rent' => null],
                            ['id' => 'R010', 'name' => 'Recovery Room', 'floor' => 'First Floor', 'is_ward' => false, 'beds' => null, 'rent' => null],
                        ];
                    @endphp
                    @foreach($rooms as $index => $room)
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{{ $index + 1 }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{{ $room['id'] }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{{ $room['name'] }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{{ $room['floor'] }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm">
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full {{ $room['is_ward'] ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800' }}">
                                    {{ $room['is_ward'] ? 'Yes' : 'No' }}
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {{ $room['beds'] ?? 'N/A' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {{ $room['rent'] ? 'Rs ' . number_format($room['rent'], 2) : 'N/A' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <a href="#" class="text-blue-600 hover:text-blue-900 mr-3">Edit</a>
                                <a href="#" class="text-red-600 hover:text-red-900">Delete</a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const isWardCheckbox = document.getElementById('is_ward');
            const wardDetailsDiv = document.getElementById('ward_details');
            const numberOfBedsInput = document.getElementById('number_of_beds');
            const perDayRentInput = document.getElementById('per_day_rent');

            function toggleWardDetails() {
                if (isWardCheckbox.checked) {
                    wardDetailsDiv.classList.remove('hidden');
                    numberOfBedsInput.setAttribute('required', 'required');
                    perDayRentInput.setAttribute('required', 'required');
                } else {
                    wardDetailsDiv.classList.add('hidden');
                    numberOfBedsInput.removeAttribute('required');
                    perDayRentInput.removeAttribute('required');
                    // Optionally clear values when hidden
                    numberOfBedsInput.value = '';
                    perDayRentInput.value = '';
                }
            }

            // Initial check on page load
            toggleWardDetails();

            // Listen for changes on the checkbox
            isWardCheckbox.addEventListener('change', toggleWardDetails);
        });
    </script>
@endsection
