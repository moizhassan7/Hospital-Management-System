@extends('layouts.app')

@section('content')
    <div class="flex items-center justify-between mb-6">
        <h2 class="text-3xl font-bold text-gray-800">Add New Speciality</h2>
        <a href="{{ route('departments.index') }}" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded-lg shadow-md transition-colors duration-200 ease-in-out flex items-center">
            <svg class="w-5 h-5 inline-block mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
            Back to Departments
        </a>
    </div>

    <!-- Add Speciality Form -->
    <div class="bg-white rounded-xl shadow-lg p-6 mb-8">
        <h3 class="text-2xl font-semibold text-gray-800 mb-4">Speciality Details</h3>
        <form action="#" method="POST"> {{-- Action will be updated later for actual submission --}}
            @csrf {{-- Laravel CSRF token --}}
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                    <label for="department_id" class="block text-gray-700 text-sm font-bold mb-2">Department:</label>
                    <select id="department_id" name="department_id" class="shadow appearance-none border rounded-lg w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
                        <option value="">Select a Department</option>
                        {{-- Static Departments for dropdown --}}
                        @php
                            $departments = [
                                ['id' => 'D001', 'name' => 'Cardiology'],
                                ['id' => 'D002', 'name' => 'Pediatrics'],
                                ['id' => 'D003', 'name' => 'Neurology'],
                                ['id' => 'D004', 'name' => 'Orthopedics'],
                                ['id' => 'D005', 'name' => 'Oncology'],
                                ['id' => 'D006', 'name' => 'Radiology'],
                                ['id' => 'D007', 'name' => 'Emergency'],
                                ['id' => 'D008', 'name' => 'Dermatology'],
                                ['id' => 'D009', 'name' => 'Gastroenterology'],
                                ['id' => 'D010', 'name' => 'Urology'],
                            ];
                        @endphp
                        @foreach($departments as $dept)
                            <option value="{{ $dept['id'] }}">{{ $dept['name'] }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label for="speciality_name" class="block text-gray-700 text-sm font-bold mb-2">Speciality Name:</label>
                    <input type="text" id="speciality_name" name="speciality_name" class="shadow appearance-none border rounded-lg w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="e.g., Cardiac Surgery" required>
                </div>
            </div>
            <div class="flex justify-end">
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-full shadow-lg transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                    Add Speciality
                </button>
            </div>
        </form>
    </div>

    <!-- Speciality List Table -->
    <div class="bg-white rounded-xl shadow-lg p-6">
        <h3 class="text-2xl font-semibold text-gray-800 mb-4">Existing Specialities</h3>
        <div class="overflow-x-auto">
            <table class="min-w-full bg-white rounded-lg overflow-hidden">
                <thead class="bg-gray-100 border-b border-gray-200">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sr. No.</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Speciality ID</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Speciality</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Department</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    {{-- Static Speciality Data --}}
                    @php
                        $specialities = [
                            ['id' => 'S001', 'name' => 'Cardiac Surgery', 'department' => 'Cardiology'],
                            ['id' => 'S002', 'name' => 'Pediatric Oncology', 'department' => 'Pediatrics'],
                            ['id' => 'S003', 'name' => 'Neurophysiology', 'department' => 'Neurology'],
                            ['id' => 'S004', 'name' => 'Joint Replacement', 'department' => 'Orthopedics'],
                            ['id' => 'S005', 'name' => 'Radiation Therapy', 'department' => 'Oncology'],
                            ['id' => 'S006', 'name' => 'Diagnostic Imaging', 'department' => 'Radiology'],
                            ['id' => 'S007', 'name' => 'Trauma Care', 'department' => 'Emergency'],
                            ['id' => 'S008', 'name' => 'Cosmetic Dermatology', 'department' => 'Dermatology'],
                            ['id' => 'S009', 'name' => 'Endoscopy', 'department' => 'Gastroenterology'],
                            ['id' => 'S010', 'name' => 'Kidney Transplant', 'department' => 'Urology'],
                        ];
                    @endphp
                    @foreach($specialities as $index => $spec)
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{{ $index + 1 }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{{ $spec['id'] }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{{ $spec['name'] }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{{ $spec['department'] }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <a href="#" class="text-blue-600 hover:text-blue-900 mr-3">Edit</a>
                                <a href="#" class="text-red-600 hover:text-red-900">Delete</a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
